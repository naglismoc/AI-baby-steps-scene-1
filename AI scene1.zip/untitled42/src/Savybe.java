public class Savybe extends KriterijaiPagal5Pojucius{
   private boolean arAktyvu;
   private String pavadinimas;

    public Savybe( String pavadinimas,int[] rega, int[] klausa, int[] uosle, int[] skonis, int[] lytejimas, boolean arAktyvu) {
        super(rega, klausa, uosle, skonis, lytejimas);
        this.arAktyvu = arAktyvu;
        this.pavadinimas = pavadinimas;
    }

    public boolean isArAktyvu() {
        return arAktyvu;
    }

    public void setArAktyvu(boolean arAktyvu) {
        this.arAktyvu = arAktyvu;
    }

    public String getPavadinimas() {
        return pavadinimas;
    }

    public void setPavadinimas(String pavadinimas) {
        this.pavadinimas = pavadinimas;
    }
}
