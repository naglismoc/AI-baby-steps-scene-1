public class Relation {
    String pirmas;
    String antras;
    String resultas;

    public Relation(String pirmas, String antras, String resultas) {
        this.pirmas = pirmas;
        this.antras = antras;
        this.resultas = resultas;
    }
}
