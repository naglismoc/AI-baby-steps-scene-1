import java.util.ArrayList;

public class Objektas {
    private String pavadinimas;
    ArrayList<Savybe> savybes;

    public Objektas(String pavadinimas, ArrayList<Savybe> savybes) {
        this.pavadinimas = pavadinimas;
        this.savybes = savybes;
    }

    public String getPavadinimas() {
        return pavadinimas;
    }

    public void setPavadinimas(String pavadinimas) {
        this.pavadinimas = pavadinimas;
    }
}
