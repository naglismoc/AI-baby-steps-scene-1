import java.util.ArrayList;
import java.util.Scanner;

public class Main {
// rasyti skaidoma objekta, poto taip.
    public static void main(String[] args) {
        ArrayList<String> aplinka = new ArrayList<>();
        aplinka.add("kede");
        aplinka.add("sviesa");
        aplinka.add("jungiklis");
        aplinka.add("lempa");
        aplinka.add("stalas");
        aplinka.add("knyga");
        ArrayList<Relation> relationses = new ArrayList<>();
        // relationses.add(new Relation("stalas","kede","resultas"));
        //objektas, jo savybes, veiksmai ka jis gali daryti nepriklausomai, veiksmai ka gali daryti santykyje
        for (int i = 0; i < aplinka.size(); i++) {
            for (int j = 0; j < aplinka.size(); j++) {
                relationses.add(new Relation(aplinka.get(i), aplinka.get(j), ""));
            }
        }

//       objektas veiksmas read
//        //ziuri per visus
//        objektus itemus //ir ziuri ar kuris is ju turi
//                objekta savybe
//               // read ir tikrina ar galima inicijuoti.
//        savybe read atrodo taip. turi true/false ar tai vyksta. turi kriterijus kada read imanoma.
//        kol kas pagal 5 pojucius is zmogaus perspektyvos. t.y terpe kurioje read imanoma.
//        pvz sviesumas nuo 30 iki 80 procentu. ziurima ar parametras sviesumas yra normose. jei ne
//        tada inicijuojama sviesinimo procesas. klausimas kur ji laikyti. ar kaip 5 dalykus
//        pagal 5 sences ar kisti i read metoda nes gal atsiras daugiau poreikiu nei 5, isvengsim
//        metodu klasifikavimo. procesas sviesa ziuri is turimu itemu kurie turi tiesiogini sviesa kriteriju.
//                tai bus lempa. lempos sviesumas aprasytas kaip boolean ir vienas 5 parametru pagal pojucius
//                pliusuojantis. arba parametru prizme rasyti same number, 25 25 arba boolean kitiems kintamiesiems
//                inicijuoti. arba sviesumas = 0 100 nes jai vienodai ribos ir 25 kiek gali prideti.

        int keistiParametraIKuriaPuse = 0;
        String i_want = "skaityti";
        veiksmas(keistiParametraIKuriaPuse, i_want);
    }

    public static void veiksmas(int keistiParametraIKuriaPuse, String i_want) {
        //parametrai
        int rega = 20;
        int klausa = 0;
        int uosle = 0;
        int skonis = 0;
        int lytejimas = 0;
        ArrayList i_wantArray = new ArrayList();
        i_wantArray.add(i_want);
        Main main = new Main();

        //sukuriu visu objektu masyva
        ArrayList<Objektas> zinomiObjektai = new ArrayList<>();

        //sukuriu savybe kuria gales tureti objektai
        Savybe skaityti = new Savybe("skaityti", new int[]{0, 25, 80}, new int[]{0, 0, 100}, new int[]{0, 0, 100}, new int[]{0, 0, 100}, new int[]{0, 0, 100}, false);
        Savybe sviesti = new Savybe("sviesti", new int[]{50, 0, 100}, new int[]{0, 0, 100}, new int[]{0, 0, 100}, new int[]{0, 0, 100}, new int[]{0, 0, 100}, false);
        //sukuriu objektus
        Objektas stalas = new Objektas("stalas", new ArrayList<Savybe>());
        Objektas knyga = new Objektas("knyga", new ArrayList<Savybe>());
        Objektas zurnalas = new Objektas("zurnalas", new ArrayList<Savybe>());
        Objektas lankstinukas = new Objektas("lankstinukas", new ArrayList<Savybe>());
        Objektas kede = new Objektas("kede", new ArrayList<Savybe>());
        Objektas jungiklis = new Objektas("jungiklis", new ArrayList<Savybe>());
        Objektas lempa = new Objektas("lempa", new ArrayList<Savybe>());
        //sudedu objektus i masyva
        zinomiObjektai.add(stalas);
        zinomiObjektai.add(kede);
        zinomiObjektai.add(knyga);
        zinomiObjektai.add(jungiklis);
        zinomiObjektai.add(lempa);
        zinomiObjektai.add(zurnalas);
        zinomiObjektai.add(lankstinukas);
        //priskiriu objektams savybes veliau reikes tiesiai deti, ne per isore kurti.
        knyga.savybes.add(skaityti);
        zurnalas.savybes.add(skaityti);
        lankstinukas.savybes.add(skaityti);
        lempa.savybes.add(sviesti);

        //susikuriu keleta pagalbiniu kintamuju
        String[] kaGalima = new String[9999999];
        int[] kaGalimaIndex = new int[9999999];
        int[] savybesindex = new int[9999999];
        int temp = -1;


        //patikrinu kurie is turimu objektu turi pageidautina savybe ir juos isvardinu
        for (int a = i_wantArray.size(); a > 0; a--) {
            for (int i = 0; i < zinomiObjektai.size(); i++) {
                for (int j = 0; j < zinomiObjektai.get(i).savybes.size(); j++) {
                    if (i_wantArray.get(a - 1).equals(zinomiObjektai.get(i).savybes.get(j).getPavadinimas())) {
                        temp++;
                        savybesindex[temp] = j;
                        kaGalima[temp] = zinomiObjektai.get(i).getPavadinimas();
                        kaGalimaIndex[temp] = i;
                    }
                }
            }
            if (temp == -1) {
                System.out.println("neradome objektu su kuriais butu galima vykdyti veiksma " + i_want);
            } else {
                System.out.print(i_want + " galima: ");
                for (int h = 0; h <= temp; h++) {
                    System.out.print(kaGalima[h]);
                    if (h <= temp - 1) {
                        System.out.print(", ");
                    }
                    if (h == temp) {
                        System.out.print(".");
                    }
                }
            }
            //pasirenku objekta su kuriuo noriu atlikti veiksma
            System.out.println("");
            System.out.println("Ka norite " + i_want + "?");
            Scanner sc = new Scanner(System.in);
            String input = sc.nextLine();
            int[] savybesKlausa;
            int[] savybesRega;
            int[] savybesSkonis;
            int[] savybesUosle;
            int[] savybesLytejimas;

            //pasirenku is ATRINKTU objektu pasirinktaji ir tikrinu ar 5 savybes leidzia atlikti veiksma. T.y ar jis atliktinas
            for (int i = 0; i <= temp; i++) {
                if (input.equals(kaGalima[i])) {

                    savybesKlausa = zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).getKlausa();
                    savybesRega = zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).getRega();
                    savybesSkonis = zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).getSkonis();
                    savybesUosle = zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).getUosle();
                    savybesLytejimas = zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).getLytejimas();

                    //pasiziurime ar objektines savybes "ijungti" klausos parametras gali buti ijungiamas siame objekte. jei taip darom if
                    // ne visos objektines savybes turi galimybe buti keiciamo buvio.
                    main.tikrinamKriterijus(savybesKlausa, klausa,"klausa", i, keistiParametraIKuriaPuse, zinomiObjektai, kaGalimaIndex, kaGalima, savybesindex, temp);
                    main.tikrinamKriterijus(savybesRega, rega,"rega", i, keistiParametraIKuriaPuse, zinomiObjektai, kaGalimaIndex, kaGalima, savybesindex, temp);
                    main.tikrinamKriterijus(savybesSkonis, skonis,"skonis", i, keistiParametraIKuriaPuse, zinomiObjektai, kaGalimaIndex, kaGalima, savybesindex, temp);
                    //rega
                    if (savybesRega[0] != 0) {
                       // System.out.println("zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).isArAktyvu() = " + zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).isArAktyvu());
                        //ziurim ar reikia inicijuoti objekto savybes pokyti ir ar galima
                        if (keistiParametraIKuriaPuse > 0 && zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).isArAktyvu() == false) {
                            zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).setArAktyvu(true);

                            System.out.println("panaudojome " + kaGalima[i] + " kadangi tai buvo neijungta ir padidinome sviesos. daikto veiksmo buvi pakeiteme i aktyvu. ziurime toliau ar kiti parametrai atitinka pirminio tikslo kriterijus. ");
                        } else if (keistiParametraIKuriaPuse < 0 && zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).isArAktyvu() == true) {
                            System.out.println("panaudojome" + kaGalima[i] + " ir pamazinome sviesos");
                        }
                    }
                    if (savybesRega[1] <= rega && savybesRega[2] >= rega) {
                        System.out.println("regos jusles parametrai netrugdo igivendinti veiksmo " + i_wantArray.get(a - 1));
                    } else if (savybesRega[1] > rega && savybesRega[2] >= rega) {
                        System.out.println("aplinkoje per tamsu, kad galetume " + i_want);
                        System.out.println("ar noretumete pabandyti pakeisti sviesos parametra i tinkama?");
                        input = sc.nextLine();
                        if (input.equals("taip")) {
                            keistiParametraIKuriaPuse = 1;//galbut visose kitose outcomes'uose reiktu sudeti =0;
                            i_want = "sviesti";
                            i_wantArray.add(i_want);
                            veiksmas(keistiParametraIKuriaPuse, i_want);
                        } else {
                            System.out.println("deje " + i_wantArray.get(a - 1) + " nepavyks.");
                        }

                    } else {
                        System.out.println("aplinkoje per sviesu, kad galetume " + i_wantArray.get(a - 1));
                    }
                    //skonis
                    if (savybesSkonis[1] <= rega && savybesSkonis[2] >= rega) {
                        System.out.println("skonio jusles parametrai netrugdo igivendinti veiksmo " + i_wantArray.get(a - 1));
                    } else if (savybesSkonis[1] > rega && savybesSkonis[2] >= rega) {
                        System.out.println("aplinkoje per mazai skonio, kad galetume " + i_wantArray.get(a - 1));
                    } else {
                        System.out.println("aplinkoje per daug skonio, kad galetume " + i_wantArray.get(a - 1));
                    }
                    //uosle
                    if (savybesUosle[1] <= rega && savybesUosle[2] >= rega) {
                        System.out.println("uosles jusles parametrai netrugdo igivendinti veiksmo " + i_wantArray.get(a - 1));
                    } else if (savybesUosle[1] > rega && savybesUosle[2] >= rega) {
                        System.out.println("aplinkoje per mazai kvapo, kad galetume " + i_wantArray.get(a - 1));
                    } else {
                        System.out.println("aplinkoje per daug kvapo, kad galetume " + i_wantArray.get(a - 1));
                    }
                    //lytejimas
                    if (savybesLytejimas[1] <= rega && savybesLytejimas[2] >= rega) {
                        System.out.println("lytejimo jusles parametrai netrugdo igivendinti veiksmo " + i_wantArray.get(a - 1));
                    } else if (savybesLytejimas[1] > rega && savybesLytejimas[2] >= rega) {
                        System.out.println("aplinkoje per mazai lytejimo, kad galetume " + i_wantArray.get(a - 1));
                    } else {
                        System.out.println("aplinkoje per daug lytejimo, kad galetume " + i_wantArray.get(a - 1));
                    }


                } else {
                    //  System.out.println("nesutapo inputas");
                }

            }
        }
    }

    // daryta nuo klausa sablono, pritaikyta 5 sences
    public  int tikrinamKriterijus(int[] savybesKlausa, int klausa,String pojutis, int i,int keistiParametraIKuriaPuse,ArrayList<Objektas>zinomiObjektai,int[]kaGalimaIndex ,String[] kaGalima,int[] savybesindex,int temp) {

        if (savybesKlausa[0] != 0) {
          //  System.out.println("zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).isArAktyvu() = " + zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).isArAktyvu());
            if (keistiParametraIKuriaPuse > 0 && zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).isArAktyvu() == false) {
                System.out.println("panaudojome " + kaGalima[i] + " kadangi tai buvo neijungta ir padidinome "+pojutis);
            } else if (keistiParametraIKuriaPuse < 0 && zinomiObjektai.get(kaGalimaIndex[i]).savybes.get(savybesindex[temp]).isArAktyvu() == true) {
                System.out.println("panaudojome" + kaGalima[i] + " ir pamazinome "+pojutis);
            }
        }
        //klausa

        if (savybesKlausa[1] <= klausa && savybesKlausa[2] >= klausa) {
            System.out.println("klausos jusles parametrai netrugdo igivendinti veiksmo " + kaGalima[i]);
        } else if (savybesKlausa[1] > klausa && savybesKlausa[2] >= klausa) {
            System.out.println("aplinkoje per daug "+pojutis+", kad galetume " + kaGalima[i]);
        } else {
            System.out.println("aplinkoje per mazai"+pojutis+", kad galetume " + kaGalima[i]);
        }return 1;
    }

}


