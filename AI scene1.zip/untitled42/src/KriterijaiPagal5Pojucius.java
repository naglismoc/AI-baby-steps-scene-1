public class KriterijaiPagal5Pojucius {
   private int[] rega;
   private  int[] klausa;
   private  int[] uosle;
   private  int[] skonis;
   private  int[] lytejimas;

    public KriterijaiPagal5Pojucius(int[] rega, int[] klausa, int[] uosle, int[] skonis, int[] lytejimas) {
        this.rega = rega;
        this.klausa = klausa;
        this.uosle = uosle;
        this.skonis = skonis;
        this.lytejimas = lytejimas;
    }

    public int[] getRega() {
        return rega;
    }

    public void setRega(int[] rega) {
        this.rega = rega;
    }

    public int[] getKlausa() {
        return klausa;
    }

    public void setKlausa(int[] klausa) {
        this.klausa = klausa;
    }

    public int[] getUosle() {
        return uosle;
    }

    public void setUosle(int[] uosle) {
        this.uosle = uosle;
    }

    public int[] getSkonis() {
        return skonis;
    }

    public void setSkonis(int[] skonis) {
        this.skonis = skonis;
    }

    public int[] getLytejimas() {
        return lytejimas;
    }

    public void setLytejimas(int[] lytejimas) {
        this.lytejimas = lytejimas;
    }
}
